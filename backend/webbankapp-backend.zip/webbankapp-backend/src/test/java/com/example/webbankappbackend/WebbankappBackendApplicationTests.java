package com.example.webbankappbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebbankappBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
