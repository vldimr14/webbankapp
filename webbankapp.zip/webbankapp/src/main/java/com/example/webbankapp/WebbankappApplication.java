package com.example.webbankapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebbankappApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebbankappApplication.class, args);
	}

}
